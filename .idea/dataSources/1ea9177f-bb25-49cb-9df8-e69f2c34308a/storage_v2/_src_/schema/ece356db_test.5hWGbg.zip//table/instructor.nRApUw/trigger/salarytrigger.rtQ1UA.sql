create definer = root@localhost trigger SalaryTrigger
  before UPDATE
  on instructor
  for each row
BEGIN
IF NEW.salary > OLD.salary * 1.10 THEN 
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'increase higher than 10%';
END IF;
END;

