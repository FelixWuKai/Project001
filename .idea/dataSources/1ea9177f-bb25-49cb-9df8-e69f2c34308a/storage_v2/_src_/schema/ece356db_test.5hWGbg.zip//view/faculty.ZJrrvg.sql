create view faculty as
select `ece356db_test`.`instructor`.`ID`        AS `ID`,
       `ece356db_test`.`instructor`.`name`      AS `name`,
       `ece356db_test`.`instructor`.`dept_name` AS `dept_name`
from `ece356db_test`.`instructor`;

