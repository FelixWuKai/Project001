create
  definer = root@localhost procedure ProcTopSalary(IN dept_name varchar(20))
BEGIN 
	select max(salary) from instructor where instructor.dept_name = dept_name ;
END;

