create
  definer = root@localhost procedure sp_pay_raise_kai(IN inEmpID int, IN inPercentageRaise double(4, 2), OUT errorCode int)
begin

end;

