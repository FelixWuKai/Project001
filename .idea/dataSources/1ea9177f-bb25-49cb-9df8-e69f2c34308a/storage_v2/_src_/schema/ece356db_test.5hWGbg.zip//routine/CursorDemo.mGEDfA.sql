create
  definer = root@localhost procedure CursorDemo()
BEGIN
	DECLARE year INT DEFAULT 2016;
    DECLARE my_id VARCHAR(5);
    DECLARE my_dept_name VARCHAR(20);
    DECLARE done INT DEFAULT 0;
    DECLARE cur CURSOR FOR SELECT ID, dept_name FROM instructor;
    DECLARE CONTINUE HANDLER FOR
		NOT FOUND SET done = 1;
	OPEN cur;
    my_loop: LOOP
    FETCH cur INTO my_id, my_dept_name;
    IF done = 1 THEN LEAVE my_loop;
    END IF;
    IF my_dept_name= 'Biology' THEN INSERT INTO teaches VALUES (my_id, 'BIO-101', 1, 'Summer', year);
    SET year = year + 0;END IF;END LOOP my_loop;
    CLOSE cur;
    END;

